//
//  ObjectView.swift
//  gesture demo
//
//  Created by Alina on 11/9/18.
//  Copyright © 2018 Alina1995. All rights reserved.
//

import UIKit

class ObjectView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.orange
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
 
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch: UITouch! = touches.first! as UITouch
        self.center = touch.location(in: self.superview)
        
        let label = UILabel(frame: frame)
        print("frame.origin.x: \(label.frame.origin.x)")
        print("frame.origin.y: \(label.frame.origin.y)")
        print("frame.size.width: \(label.frame.size.width)")
        print("frame.size.height: \(label.frame.size.height)")
        
        print("bounds.origin.x: \(label.bounds.origin.x)")
        print("bounds.origin.y: \(label.bounds.origin.y)")
        print("bounds.size.width: \(label.bounds.size.width)")
        print("bounds.size.height: \(label.bounds.size.height)")
    }
    
    
    
}
