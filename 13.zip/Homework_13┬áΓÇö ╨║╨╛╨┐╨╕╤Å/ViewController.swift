//
//  ViewController.swift
//  gesture demo
//
//  Created by Alina on 11/7/18.
//  Copyright © 2018 Alina1995. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var frameOfObjectLabel: UILabel!
    
    @IBOutlet weak var boundsOfObjectLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func Start(_ sender: UIButton) {
        let frame = CGRect(x: 100, y: 100, width: 90, height: 90)
        let newView = ObjectView(frame: frame)
        newView.contentMode = .scaleAspectFit
        self.view.addSubview(newView)
        
        let label = UILabel(frame: frame)
        frameOfObjectLabel.text = "Frame: \(label.frame)"
        boundsOfObjectLabel.text = "Bounds: \(label.bounds)"
    }
    
}


