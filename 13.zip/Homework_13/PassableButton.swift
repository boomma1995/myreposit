//
//  PassableButton.swift
//  gesture demo
//
//  Created by Alina on 11/8/18.
//  Copyright © 2018 Alina1995. All rights reserved.
//

import UIKit

class PassableUIButton: UIButton {
    var params: Dictionary<String,Any>
    
    override init(frame:CGRect) {
        self.params = [:]
        super.init(frame:frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.params = [:]
        super.init(coder: aDecoder)
    }
    
}
