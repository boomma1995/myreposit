//
//  ViewController.swift
//  Homework14_2
//
//  Created by Alina on 11/10/18.
//  Copyright © 2018 Alina1995. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

